/*
********************************************************************************************************
�ļ�����bsp_NVIC.c
��  �ܣ��ж�����

uart��time�ж�


*********************************************************************************************************
*/

#include "bsp_nvic.h"

/*
********************************************************************************************************
�������ƣ�void NVIC_Config(void)

*********************************************************************************************************
*/
void NVIC_Config(void)
{
	NVIC_TIM1_Config();
	NVIC_Exti_PA8_Config();
}





//����timer1���ж�����
void NVIC_TIM1_Config(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitStructure.NVIC_IRQChannel=TIM1_UP_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void NVIC_Exti_PA8_Config(void)
{
	NVIC_InitTypeDef NVIC_InitStruct;
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//
	
	//�ⲿ�ж�
	NVIC_InitStruct.NVIC_IRQChannel=EXTI9_5_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=0;
	NVIC_Init(&NVIC_InitStruct);
	

}

//------------------End of File----------------------------
