#ifndef _BSP_EXTI_H
#define _BSP_EXTI_H

//DRVͷ�ļ�
#include "stm32f10x.h"

void Exti_PA8_Init(void);


#endif
