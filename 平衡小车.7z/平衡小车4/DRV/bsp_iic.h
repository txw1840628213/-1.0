#ifndef __BSP_IIC_H
#define __BSP_IIC_H
#include "stm32f10x.h"
///*
//********************************************************************************************************
//�ļ�����iic.c
//��  �ܣ�IIC��ʼ�����д�ĺ���
//*********************************************************************************************************
//*/



#include "bsp_iic.h"


void IIC_Read(I2C_TypeDef* I2C, uint8_t dev_addr, uint8_t reg_addr, uint8_t* pBuf, uint16_t num);
void IIC_Write(I2C_TypeDef* I2C, uint8_t dev_addr, uint8_t reg_addr, uint8_t* pBuf, uint16_t num);
void IIC_ReadByte(I2C_TypeDef* I2C, uint8_t dev_addr, uint8_t reg_addr, uint8_t* pData);
void IIC_WriteByte(I2C_TypeDef* I2C, uint8_t dev_addr, uint8_t reg_addr, uint8_t data);
void IIC_Init(void);


#endif
















